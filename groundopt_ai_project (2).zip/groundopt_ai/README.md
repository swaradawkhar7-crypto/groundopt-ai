# GroundOpt AI — FUSION 2026 SPACE-04

A Streamlit dashboard prototype for ground-station scheduling. It compares a First-Come, First-Served (FCFS) baseline with an OR-Tools CP-SAT optimization model using reproducible synthetic satellite passes.

## Run locally

1. Install Python 3.10 or newer.
2. Extract this ZIP and open the `groundopt_ai` folder in VS Code.
3. Open a terminal in that folder and run:

   ```bash
   python -m venv .venv
   ```

4. Activate the environment:
   - Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
   - macOS/Linux: `source .venv/bin/activate`
5. Install dependencies: `pip install -r requirements.txt`
6. Launch: `streamlit run app.py`

The app should open in your browser. If PowerShell blocks activation, try `python -m pip install -r requirements.txt` in a terminal where Python is available, then run `python -m streamlit run app.py`.

## Model overview

- FCFS sorts by start time and accepts a pass if its assigned ground station has no overlapping accepted pass.
- Optimizer creates one binary decision per pass, prevents overlapping passes on the same station, and maximizes `priority × data_mb`.
- Data are synthetic and intended for a prototype/demo, not real mission operations.

## Current simplifications

No station outages, antenna slew/setup times, downlink-rate variation, weather constraints, or real ephemeris data. Pass windows are treated as fixed, and the model does not currently enforce satellite-side conflicts across stations.
