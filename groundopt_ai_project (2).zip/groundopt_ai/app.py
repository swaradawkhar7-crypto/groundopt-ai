import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from ortools.sat.python import cp_model

st.set_page_config(page_title='GroundOpt AI | Mission Control', page_icon='🛰️', layout='wide')
st.markdown('''<style>
.stApp {background:linear-gradient(135deg,#07111f 0%,#0b1830 60%,#101d35 100%);color:#e7eefb}
[data-testid="stSidebar"] {background:#091426}
[data-testid="stMetric"] {background:#101f35;border:1px solid #263c5b;padding:16px;border-radius:12px}
h1,h2,h3 {color:#e8f2ff}
</style>''', unsafe_allow_html=True)

st.title('🛰️ GroundOpt AI')
st.caption('GROUND STATION SCHEDULING • FUSION 2026 • SPACE-04')
st.write('Optimize satellite downlink opportunities across ground stations, and compare against a simple First-Come, First-Served (FCFS) baseline.')

@st.cache_data
def make_passes(n=24, seed=7):
    rng=np.random.default_rng(seed)
    sats=[f'SAT-{i:02d}' for i in range(1,9)]
    stations=['GS-West','GS-Central','GS-East']
    rows=[]
    for i in range(n):
        start=int(rng.integers(0,540))
        dur=int(rng.integers(25,91))
        rows.append({'pass_id':f'PASS-{i+1:03d}','satellite':rng.choice(sats),'station':rng.choice(stations),
                     'start_min':start,'end_min':min(600,start+dur),'priority':int(rng.integers(1,6)),
                     'data_mb':int(rng.integers(200,2200))})
    return pd.DataFrame(rows).sort_values(['start_min','end_min']).reset_index(drop=True)

with st.sidebar:
    st.header('Mission settings')
    n=st.slider('Synthetic pass count',10,50,24)
    seed=st.number_input('Random seed',min_value=1,max_value=9999,value=7)
    st.caption('Times are minutes from 00:00 in a simplified 10-hour planning horizon.')

passes=make_passes(n,int(seed))
st.subheader('Pass manifest')
edited=st.data_editor(passes, use_container_width=True, num_rows='dynamic', hide_index=True,
                      column_config={'start_min':st.column_config.NumberColumn(min_value=0,max_value=599),
                                     'end_min':st.column_config.NumberColumn(min_value=1,max_value=600),
                                     'priority':st.column_config.NumberColumn(min_value=1,max_value=5)})

def valid_rows(df):
    df=df.copy()
    df['start_min']=pd.to_numeric(df['start_min'],errors='coerce')
    df['end_min']=pd.to_numeric(df['end_min'],errors='coerce')
    df['priority']=pd.to_numeric(df['priority'],errors='coerce')
    df['data_mb']=pd.to_numeric(df['data_mb'],errors='coerce')
    return df.dropna(subset=['pass_id','station','start_min','end_min','priority','data_mb']).query('end_min > start_min and start_min >= 0 and end_min <= 600').reset_index(drop=True)

def fcfs(df):
    accepted=[]
    for _,r in df.sort_values(['start_min','end_min']).iterrows():
        conflict=any(a['station']==r['station'] and r['start_min'] < a['end_min'] and a['start_min'] < r['end_min'] for a in accepted)
        if not conflict: accepted.append(r.to_dict())
    return pd.DataFrame(accepted)

def optimize(df):
    if df.empty: return df.copy()
    model=cp_model.CpModel(); x=[model.NewBoolVar(f'x{i}') for i in range(len(df))]
    for i in range(len(df)):
        for j in range(i+1,len(df)):
            a,b=df.iloc[i],df.iloc[j]
            if a['station']==b['station'] and a['start_min'] < b['end_min'] and b['start_min'] < a['end_min']:
                model.Add(x[i]+x[j] <= 1)
    # Maximize priority-weighted data volume.
    weights=[int(max(1,r['priority']*r['data_mb'])) for _,r in df.iterrows()]
    model.Maximize(sum(weights[i]*x[i] for i in range(len(df))))
    solver=cp_model.CpSolver(); solver.parameters.max_time_in_seconds=5
    status=solver.Solve(model)
    if status not in (cp_model.OPTIMAL,cp_model.FEASIBLE): return pd.DataFrame(columns=df.columns)
    return df[[solver.Value(x[i])==1 for i in range(len(df))]].copy()

clean=valid_rows(edited)
if len(clean) != len(edited): st.warning('Some rows were ignored because required values were missing or the time window was invalid.')
base=fcfs(clean); opt=optimize(clean)
def score(df): return int((df['priority']*df['data_mb']).sum()) if not df.empty else 0
c1,c2,c3,c4=st.columns(4)
c1.metric('Available passes',len(clean)); c2.metric('FCFS scheduled',len(base)); c3.metric('Optimized scheduled',len(opt)); c4.metric('Optimizer score',f'{score(opt):,}')
left,right=st.columns(2)
with left:
    st.subheader('Scheduling score')
    compare=pd.DataFrame({'Method':['FCFS','GroundOpt AI'],'Weighted data score':[score(base),score(opt)],'Scheduled passes':[len(base),len(opt)]})
    fig=px.bar(compare,x='Method',y='Weighted data score',color='Method',template='plotly_dark',title='Priority × data volume')
    fig.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',showlegend=False)
    st.plotly_chart(fig,use_container_width=True)
with right:
    st.subheader('Optimized station timeline')
    if not opt.empty:
        timeline=opt.copy(); timeline['start_label']=timeline['start_min'].astype(int).astype(str); timeline['end_label']=timeline['end_min'].astype(int).astype(str)
        fig2=px.timeline(timeline,x_start='start_min',x_end='end_min',y='station',color='satellite',hover_data=['pass_id','priority','data_mb'],template='plotly_dark',title='Time in minutes from horizon start')
        fig2.update_yaxes(autorange='reversed'); fig2.update_layout(paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)')
        st.plotly_chart(fig2,use_container_width=True)
    else: st.info('No valid passes to schedule.')

tab1,tab2=st.tabs(['Optimized schedule','FCFS baseline'])
with tab1: st.dataframe(opt.sort_values(['station','start_min']),use_container_width=True,hide_index=True)
with tab2: st.dataframe(base.sort_values(['station','start_min']),use_container_width=True,hide_index=True)
st.download_button('Download optimized schedule CSV',opt.to_csv(index=False).encode('utf-8'),'groundopt_schedule.csv','text/csv')
st.caption('Prototype limitations: synthetic pass data, fixed time windows, one pass per station at a time. No slew/setup times, station outages, link rates, or real orbital data are modeled.')
